MCR Spanish WordNet 3.0 database files. To be read by the NTLK WordNet reader.

These files were created from the Multilingual Central Repository 3.0.
The latest Spanish MCR 3.0 files can be downloaded from http://adimen.si.ehu.es/web/MCR/
The latest version of the transformation process can be found in https://github.com/pln-fing-udelar/wn-mcr-transform

=================================================
Usage:
1 - Extract the files into a folder.
2 - From a Python shell, import the NLTK library.
    >> import nltk
3 - Create a WordNet reader.
    >> wn = nltk.corpus.reader.wordnet.WordNetCorpusReader(<path to the extracted files>)

Now you can use the object wn to query the contents of WordNet in Spanish, for example:
    >> print wn.synset("entidad.n.01").definition
